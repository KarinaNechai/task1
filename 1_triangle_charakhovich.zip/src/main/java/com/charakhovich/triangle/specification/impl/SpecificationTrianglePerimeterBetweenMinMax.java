package com.charakhovich.triangle.specification.impl;

import com.charakhovich.triangle.action.TriangleAction;
import com.charakhovich.triangle.entity.Triangle;

import java.util.function.Predicate;

public class SpecificationTrianglePerimeterBetweenMinMax implements Predicate<Triangle> {
    private TriangleAction triangleAction = TriangleAction.getInstance();
    private double minPerimeter;
    private double maxPerimeter;
    public SpecificationTrianglePerimeterBetweenMinMax(double minPerimeter, double maxPerimeter) {
        this.minPerimeter=minPerimeter;
        this.maxPerimeter=maxPerimeter;
    }
    @Override
    public boolean test(Triangle triangle) {
        Double perimeter=triangleAction.perimeter(triangle);
        boolean flag =perimeter>minPerimeter&&perimeter<maxPerimeter;
        return flag;
    }
}
