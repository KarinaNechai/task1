package com.charakhovich.triangle.specification;

import com.charakhovich.triangle.entity.Triangle;

import java.util.function.Predicate;

public interface SpecificationTriangle extends Predicate<Triangle> {
   // boolean specify(Triangle triangle);
}
