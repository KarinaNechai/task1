package com.charakhovich.triangle.entity;

public abstract class Shape {
}
